var express = require('express'),
path = require('path'),
bodyParser = require('body-parser'),
cons = require('consolidate'),
dust = require('dustjs-helpers'),
app = express();
const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',

  database: 'PGA_Project1', // Change the database name depending on which one you use
  password: '54321', // This is just a random password
  port: 5432,
});



var connect = "postgres://Sebastian_Project1:(Password)@localhost/PGA_Project1"; // Connect through postgres with (Password) required
app.engine('dust', cons.dust);

app.set('view engine', 'dust');
app.set('views', __dirname + '/view');

app.use(express.static(path.join(__dirname, 'public')));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

// Pulls the results
app.get('/', async function(req, res) {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT * FROM STORY');
    res.render('index', { story: result.rows });
    client.release();
  } catch (err) {
    console.error('Database error:', err.stack);
    res.status(500).send('Something went wrong');
  }
});


// Function to add data
app.post('/add', function(req, res){
    try{
      pool.query("INSERT INTO story(name, paragraph, genres) VALUES($1, $2, $3)", 
        [req.body.name, req.body.paragraph, req.body.genres]);
        res.redirect('/');
      } catch(err){
        console.error(err);
      }
})

// Function to delete data
app.delete('/delete/:id', async function(req, res){
  try{
      pool.query("DELETE FROM story WHERE id = $1", 
        [req.params.id]);
        console.log(parseFloat(req.params.id) + '\n\n\n\n\n\n\n');

        res.sendStatus(200);
      } catch(err){
        console.error(err);
      }
});


// Function to edit data
app.post('/edit', async function(req, res){
    try{
      await pool.query('UPDATE story SET name=$1, genres=$2, paragraph=$3 WHERE id=$4', [req.body.name, req.body.genres, req.body.paragraph, req.body.id]);
      res.redirect('/');
    }
    catch{
      return console.error(err);
    }

});

app.listen(3000, function(){
    console.log('Serfver started on port 3000');
});
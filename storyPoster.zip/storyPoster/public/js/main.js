$(document).ready(function(){
    $('.delete-story').on('click', function(){
        var id = $(this).data('id');
        var url = '/delete/'+id;
        if (confirm('Delete Story')){
            $.ajax({
                url: url,
                type: 'DELETE',
                success: function(result){
                    console.log('Deleting Story...');
                    window.location.href='/';
                },
                error: function(err){
                    console.log(err);
                }
            });
        }
    })
    
    $('.edit-story').on('click', function(){
        $('#edit-form-name').val($(this).data('name'));
        $('#edit-form-genres').val($(this).data('genres'));
        $('#edit-form-paragraph').val($(this).data('paragraph'));
        $('#edit-form-id').val($(this).data('id'));
    });
})
